from django.http.response import HttpResponse
from django.shortcuts import render

# Create your views here.
def registerform(request):
    return render(request,'index.html')

def stdashboard(request):
    if request.method =='POST':
        f_data=request.POST

        Adid=f_data['Adid']
        
        name=f_data['Sname']

        dob=f_data['dob']

        aadhar=f_data['aadhar']
        
        dept=f_data['dept']

        yos=f_data['yos']

        college=f_data['college']  

        contact=f_data['contact']  
        
        fname=f_data['fname']    
        
        focc=f_data['focc']  
        
        mname=f_data['mname']   
        
        mocc=f_data['mocc']



        return render(request,'dashboard/dashboard.html',{'name':name,'dept':dept,'Adid':Adid,'dob':dob,'aadhar':aadhar,'yos':yos,'college':college,'contact':contact,'fname':fname,'focc':focc,'mname':mname,"mocc":mocc})
    return render(request,'index.html')
        

def forms(request):
    return render(request,'dashboard/forms.html')
        